<?php 
session_start();
$userName = $_SESSION["user_name"] ?? "";

?>



<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">

    <link rel="manifest" href="manifest.json">
<meta name="theme-color" content="#593D28">
<link rel="apple-touch-icon" href="images/icon-192.png">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تيسير طريقك للحج</title>

    <link rel="stylesheet" href="style.css">
    <script src="language.js" defer></script>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
<script>
if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
        navigator.serviceWorker
            .register("./service-worker.js")
            .then(function () {
                console.log("Taysir PWA registered successfully");
            })
            .catch(function (error) {
                console.error("PWA registration failed:", error);
            });
    });
}
</script>
    <!-- شريط التنقل -->
    <header class="navbar">

        <div class="logo">
            <img src="images/IMG_1240.PNG" alt="شعار تيسير">
        </div>

        <nav>
            <a href="#" class="active" data-i18n="home">الصفحة الرئيسية</a>
            <div class="language-dropdown">

    <button class="language-btn" type="button" onclick="toggleLanguageMenu()" data-i18n="language">
        اللغة
    </button>

    <div class="language-menu" id="languageMenu">

        <button type="button" onclick="setLanguage('ar')">
            🇸🇦 العربية
        </button>

        <button type="button" onclick="setLanguage('en')">
            🇬🇧 English
        </button>

        <button type="button" onclick="setLanguage('id')">
            🇮🇩 Bahasa Indonesia
        </button>

    </div>

</div>
            <a href="#contact" data-i18n="contact">التواصل</a>
            <a href="#contents" data-i18n="contents">المحتويات</a>
        </nav>
<?php if (!empty($userName)): ?>
    <div class="user-account">
        👤 <?php echo htmlspecialchars($userName); ?>
    </div>
<?php endif; ?>

<button class="register-btn" onclick="window.location.href='register.php'" data-i18n="register">
    انشاء حساب
</button>

<button class="register-btn" onclick="window.location.href='login.php'" data-i18n="login">
    تسجيل الدخول
</button>
    </header>


    <section class="hero">

        <img class="hero-image"
             src="images/kabba.jpeg"
             alt="مكة والكعبة">

        <div class="hero-text">

    <span data-i18n="heroTitle">
        حجك يبدأ بالمعرفة
    </span>

    <br>

    <span data-i18n="heroText">
        دليلك التفاعلي الشامل لأداء مناسك الحج بكل سهولة
        مع أدوات تفاعلية لضمان فهمك.
    </span>
    <p class="hero-verse" lang="ar" dir="rtl">قال تعالى: ﴿وَلِلَّهِ عَلَى النَّاسِ حِجُّ الْبَيْتِ مَنِ اسْتَطَاعَ إِلَيْهِ سَبِيلًا﴾ <span>[آل عمران: 97]</span></p>
</div>

            <img class="hero-circle"
                 src="images/people.jpeg"
                 alt="أشخاص في الحج">

        </div>

    </section>


    <!-- من نحن: تعريف مختصر قبل المحتويات -->
    <section class="about-taysir" id="about" aria-labelledby="about-title">
        <h2 id="about-title" data-i18n="aboutTitle">من نحن</h2>
        <p data-i18n="aboutDescription">تيسير منصة تعليمية تفاعلية تُعرّف الحاج بمناسك الحج وخطواتها بأسلوب واضح ومبسّط، مع خرائط واختبارات تعزّز الفهم.</p>
    </section>

    <!-- المحتويات -->
    <section class="contents" id="contents">

        <h2 data-i18n="contentsTitle">المحتويات</h2>

        <div class="cards">

            <!-- البطاقة الأولى -->
            <div class="card">

                <img src="images/mapnew.jpg"
                     alt="خريطة المشاعر المقدسة">

                <h3 data-i18n="mapTitle">خريطة المشاعر المقدسة</h3>
                
<p data-i18n="mapDescription">
    استكشف خريطة المشاعر المقدسة وتعرّف على مواقع منى وعرفات ومزدلفة، من خلال عرض يساعدك على معرفة أماكن المناسك والتنقّل بينها بسهولة ووضوح، لتكون رحلتك في أداء مناسك الحج أكثر يسرًا وطمأنينة.
</p>
                <button onclick="window.location.href='map.html'" data-i18n="view">استعراض</button>
            </div>


            <!-- البطاقة الثانية -->
            <div class="card">

                <img src="images/kabba2.jpg"
                     alt="مناسك الحج">

                <h3 data-i18n="manasikTitle">مناسك الحج</h3>

<p data-i18n="manasikText">
    دليل تفصيلي يرافقك خطوة بخطوة لمناسك الحج
    بدءًا من الإحرام وحتى طواف الوداع مع توضيح
    بالصور لضمان أداء المناسك بكل سهولة ويسر.
</p>

                <button onclick="window.location.href='mansik.html'" data-i18n="startJourney">
    ابدأ رحلتك الآن
</button>
            </div>

        </div>

    </section>


    <!-- التذييل -->
   <footer id="contact">

    <div class="footer-content">

        <div class="footer-brand">

            <h2 data-i18n="contactTitle">
                التواصل
            </h2>

            <p data-i18n="footerDescription">
                تيسير، رفيقك للتعرّف على مناسك الحج بخطوات واضحة.
            </p>

        </div>

        <div class="footer-contact">

            <h3 data-i18n="emailLabel">
                البريد الإلكتروني
            </h3>

            <p>
                taysir.hajj.support@gmail.com
            </p>

            <h3 data-i18n="phoneLabel">
                الهاتف
            </h3>

            <p class="footer-phone">
    <p class="footer-phone">
    <span dir="ltr">+966 564 316 118</span>
</p>

        </div>

        <div class="footer-social">

            

        </div>

    </div>

</footer>

</body>
</html>
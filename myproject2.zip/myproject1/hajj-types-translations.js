/* Translation of additional Hajj type details. */
const hajjTypesTranslations = {
  "ar": {
    "typesTitle": "أنواع النسك الثلاثة",
    "tamattuTitle": "حج التمتّع",
    "tamattuText": "يُحرم بالعمرة في أشهر الحج، فيؤدي الطواف والسعي ثم يقصّر ويتحلّل، ويُحرم بالحج من مكة يوم التروية. عليه هدي التمتع إن كان مستطيعًا، وإلا فالصيام وفق الحكم الشرعي.",
    "qiranTitle": "حج القِران",
    "qiranText": "يُحرم بالعمرة والحج معًا، أو يدخل الحج على العمرة قبل الشروع في طوافها، ويبقى على إحرامه حتى يتحلّل يوم النحر. يكفيه طواف وسعي للحج والعمرة، وعليه هدي القِران إن استطاع.",
    "ifradTitle": "حج الإفراد",
    "ifradText": "يُحرم بالحج وحده دون عمرة، ويبقى على إحرامه حتى وقت التحلّل. لا يجب عليه هدي بسبب نوع النسك، ويؤدي طواف الإفاضة وسعي الحج بحسب حاله.",
    "typesHint": "تشترك الأنواع الثلاثة في الوقوف بعرفة وسائر أركان الحج، لكن تختلف نية الإحرام وأعمال العمرة والهدي. التفاصيل الفقهية يُرجع فيها إلى مرشد شرعي مؤهل.",
    "saiNote": "في التمتع يُؤدّى سعي الحج بعد طواف الإفاضة. أما القارن والمفرد، فيجوز أن يكونا قد سعيا بعد طواف القدوم، فلا يلزمهما إعادة السعي إذا كان قد وقع صحيحًا.",
    "nahrTitle": "أعمال يوم النحر حسب نوع النسك",
    "nahrTamattuTitle": "حج التمتّع",
    "nahrTamattuText": "يرمي جمرة العقبة، ويذبح هدي التمتع إن استطاع، ثم يحلق أو يقصّر، ويؤدي طواف الإفاضة وسعي الحج. ومن عجز عن الهدي فله حكم الصيام المقرر شرعًا.",
    "nahrQiranTitle": "حج القِران",
    "nahrQiranText": "يرمي جمرة العقبة، ويذبح هدي القِران إن استطاع، ثم يحلق أو يقصّر، ويؤدي طواف الإفاضة. ويسعى للحج إذا لم يكن قد سعى سعيًا صحيحًا بعد طواف القدوم.",
    "nahrIfradTitle": "حج الإفراد",
    "nahrIfradText": "يرمي جمرة العقبة، ثم يحلق أو يقصّر، ويؤدي طواف الإفاضة. ويسعى للحج إن لم يكن قد سعى سعيًا صحيحًا بعد طواف القدوم. ولا يجب عليه الهدي لمجرد الإفراد.",
    "nahrHint": "هذه أبرز أعمال يوم النحر، ولا يلزم أداؤها جميعًا بالترتيب المذكور؛ ففي تقديم بعضها وتأخيرها تيسير وفق الأحكام الشرعية. وتستمر أعمال رمي الجمرات في أيام التشريق."
  },
  "en": {
    "typesTitle": "The Three Types of Hajj",
    "tamattuTitle": "Tamattuʿ",
    "tamattuText": "The pilgrim performs Umrah during the Hajj months, completes tawaf and saʿi, trims the hair, and leaves ihram. On the 8th of Dhul Hijjah, the pilgrim enters ihram again for Hajj. A sacrificial offering is required if able; otherwise, fasting applies according to Islamic rulings.",
    "qiranTitle": "Qiran",
    "qiranText": "The pilgrim enters ihram for Umrah and Hajj together, or adds Hajj to Umrah before beginning its tawaf, and remains in ihram until the release on the Day of Sacrifice. One tawaf and saʿi suffice for both rites; an offering is required if able.",
    "ifradTitle": "Ifrad",
    "ifradText": "The pilgrim enters ihram for Hajj alone, without Umrah, and remains in ihram until the appropriate release. No offering is required merely because of this type of Hajj. Tawaf al-Ifadah and the Hajj saʿi are performed as applicable.",
    "typesHint": "All three share the standing at Arafat and the core pillars of Hajj, but differ in intention, Umrah steps, and the offering. Ask a qualified scholar for rulings relevant to your circumstances.",
    "saiNote": "In Tamattuʿ, the Hajj saʿi follows Tawaf al-Ifadah. In Qiran and Ifrad, a valid saʿi performed after the arrival tawaf may suffice and need not be repeated.",
    "nahrTitle": "Day of Sacrifice: Acts by Hajj Type",
    "nahrTamattuTitle": "Tamattuʿ",
    "nahrTamattuText": "Stone Jamrat al-Aqabah, offer the required sacrifice if able, shave or trim the hair, then perform Tawaf al-Ifadah and the Hajj saʿi. If unable to offer the sacrifice, the prescribed fasting rules apply.",
    "nahrQiranTitle": "Qiran",
    "nahrQiranText": "Stone Jamrat al-Aqabah, offer the required sacrifice if able, shave or trim the hair, and perform Tawaf al-Ifadah. Perform the Hajj saʿi if a valid saʿi was not already completed after the arrival tawaf.",
    "nahrIfradTitle": "Ifrad",
    "nahrIfradText": "Stone Jamrat al-Aqabah, shave or trim the hair, and perform Tawaf al-Ifadah. Perform the Hajj saʿi if a valid saʿi was not already completed after the arrival tawaf. No sacrifice is required solely for choosing Ifrad.",
    "nahrHint": "These are the main acts of the Day of Sacrifice. They do not all have to be completed in this exact order; Islamic rulings allow flexibility in their sequence. Stoning continues during the days of Tashriq."
  },
  "id": {
    "typesTitle": "Tiga Jenis Ibadah Haji",
    "tamattuTitle": "Haji Tamattu",
    "tamattuText": "Jemaah melaksanakan umrah pada bulan-bulan haji, menyelesaikan tawaf dan sai, memendekkan rambut, lalu keluar dari ihram. Pada 8 Zulhijah, jemaah berihram kembali untuk haji. Dam wajib bagi yang mampu; jika tidak, berlaku ketentuan puasa menurut hukum syariat.",
    "qiranTitle": "Haji Qiran",
    "qiranText": "Jemaah berniat umrah dan haji sekaligus, atau memasukkan niat haji ke dalam umrah sebelum memulai tawaf, dan tetap berihram hingga tahalul pada hari kurban. Satu tawaf dan sai mencukupi untuk keduanya; dam diwajibkan bagi yang mampu.",
    "ifradTitle": "Haji Ifrad",
    "ifradText": "Jemaah berihram untuk haji saja, tanpa umrah, dan tetap dalam keadaan ihram hingga waktu tahalul. Tidak ada kewajiban dam semata-mata karena memilih jenis haji ini. Tawaf Ifadah dan sai haji dilakukan sesuai ketentuannya.",
    "typesHint": "Ketiganya memiliki wukuf di Arafah dan rukun haji yang sama, tetapi berbeda dalam niat, pelaksanaan umrah, dan dam. Tanyakan rincian hukum kepada pembimbing agama yang kompeten.",
    "saiNote": "Pada Tamattu, sai haji dilakukan setelah Tawaf Ifadah. Pada Qiran dan Ifrad, sai yang sah setelah tawaf kedatangan dapat mencukupi sehingga tidak perlu diulang.",
    "nahrTitle": "Amalan Hari Nahar Menurut Jenis Haji",
    "nahrTamattuTitle": "Haji Tamattu",
    "nahrTamattuText": "Melontar Jamrah Aqabah, menyembelih dam jika mampu, mencukur atau memendekkan rambut, kemudian melaksanakan Tawaf Ifadah dan sai haji. Jika tidak mampu menyembelih dam, berlaku ketentuan puasa sesuai syariat.",
    "nahrQiranTitle": "Haji Qiran",
    "nahrQiranText": "Melontar Jamrah Aqabah, menyembelih dam jika mampu, mencukur atau memendekkan rambut, dan melaksanakan Tawaf Ifadah. Sai haji dilakukan jika belum melaksanakan sai yang sah setelah tawaf kedatangan.",
    "nahrIfradTitle": "Haji Ifrad",
    "nahrIfradText": "Melontar Jamrah Aqabah, mencukur atau memendekkan rambut, dan melaksanakan Tawaf Ifadah. Sai haji dilakukan jika belum melaksanakan sai yang sah setelah tawaf kedatangan. Dam tidak wajib hanya karena memilih haji Ifrad.",
    "nahrHint": "Ini adalah amalan utama Hari Nahar. Semuanya tidak harus dilakukan persis menurut urutan tersebut; syariat memberi kelonggaran dalam urutannya. Melontar jamrah berlanjut pada hari-hari Tasyrik."
  }
};
function applyHajjTypesTranslations() {
  const lang = localStorage.getItem('siteLanguage') || 'ar';
  const words = hajjTypesTranslations[lang] || hajjTypesTranslations.ar;
  document.querySelectorAll('[data-hajj-i18n]').forEach(el => {
    const key=el.getAttribute('data-hajj-i18n');
    if(words[key]) el.textContent=words[key];
  });
}
applyHajjTypesTranslations();

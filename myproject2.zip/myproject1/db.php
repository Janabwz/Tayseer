<?php

$host = "sql310.infinityfree.com";
$username = "if0_43209766";
$password = "C3c0GdsSL1L7g";
$database = "if0_43209766_taysir";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات");
}

$conn->set_charset("utf8mb4");

?>
/* ==========================================
   ترجمة تفاصيل مناسك الحج
   Arabic - English - Indonesian
========================================== */

const manasikTranslations = {

    ar: [
        {
            kicker: "الاستعداد وبداية النسك",
            detail: "يبدأ الحاج بالإحرام من الميقات المحدد له، فينوي الدخول في النسك ويلبّي قائلًا: «لبيك اللهم لبيك، لبيك لا شريك لك لبيك». والإحرام هو نية الدخول في الحج، وليس مجرد ارتداء ملابس الإحرام.",
            points: [
                "الاغتسال والتجهّز وارتداء ملابس الإحرام المناسبة.",
                "عقد نية الحج والتلبية، مع الالتزام بمحظورات الإحرام.",
                "المحافظة على الرفق بالآخرين واتباع تعليمات الجهات المنظمة."
            ],
            note: "تختلف تفاصيل النسك بحسب نوع الحج وحال الحاج؛ تعلّم الأحكام من مصدر موثوق أو اسأل مرشدًا مؤهلًا."
        },
        {
            kicker: "اليوم الثامن من ذي الحجة",
            detail: "يتوجه الحجاج إلى منى في يوم التروية، ويقضون فيها الوقت في الصلاة والذكر والاستعداد للوقوف بعرفة. والمقصود هو السير بهدوء وتنظيم مع المجموعة واتباع المسارات والتعليمات الرسمية.",
            points: [
                "التأكد من موقع المخيم ورقم المجموعة ووسيلة التواصل مع المشرف.",
                "أداء الصلوات وفق الأحكام الشرعية المتعلقة بالسفر والحج.",
                "تجهيز الماء والأدوية الشخصية الضرورية والاحتياجات الأساسية."
            ],
            note: "قد تختلف ترتيبات الانتقال والإقامة بحسب البرنامج الرسمي للحملة؛ اتبع توجيهات المشرفين."
        },
        {
            kicker: "اليوم التاسع من ذي الحجة",
            detail: "الوقوف بعرفة ركن الحج الأعظم. يقضي الحاج هذا اليوم في عرفة مشتغلًا بالدعاء والذكر والاستغفار والتضرع إلى الله، مع الحرص على شرب الماء والراحة وتجنّب التعرض المفرط للشمس.",
            points: [
                "التأكد من الوجود داخل حدود عرفة وفي الوقت الشرعي للوقوف.",
                "الإكثار من الدعاء والتلبية والذكر، مع تخصيص وقت للراحة.",
                "البقاء مع المجموعة وعدم مغادرة الموقع دون تنسيق."
            ],
            note: "لا يُشترط صعود جبل الرحمة لصحة الوقوف بعرفة؛ العبرة بالوجود داخل حدود عرفة في وقته."
        },
        {
            kicker: "ليلة العاشر من ذي الحجة",
            detail: "بعد الإفاضة من عرفة يتجه الحجاج إلى مزدلفة، ويصلّون المغرب والعشاء جمعًا وفق الأحكام الشرعية، ويبيتون فيها بحسب الاستطاعة والترتيبات المعتمدة، ثم يستعدون للانتقال إلى منى.",
            points: [
                "الالتزام بتعليمات النقل ومواعيد التحرك المعتمدة.",
                "الراحة والاستعداد لليوم التالي، وجمع الحصى لمن احتاج إليه وفق الإرشادات.",
                "المحافظة على النظافة وعدم إعاقة ممرات المشاة."
            ],
            note: "توجد أحكام وتيسيرات لفئات مختلفة من الحجاج؛ يُرجع فيها إلى المرشد الشرعي والجهات الرسمية."
        },
        {
            kicker: "أعمال يوم النحر وأيام التشريق",
            detail: "يرمي الحاج جمرة العقبة يوم النحر، ثم يرمي الجمرات في أيام التشريق وفق ترتيبها وأوقاتها الشرعية. والرمي عبادة تؤدّى بهدوء، وليس المقصود إيذاء الآخرين أو التدافع للوصول إلى مكان قريب.",
            points: [
                "التقيد بالوقت والمسار المحددين من الحملة والجهات المنظمة.",
                "رمي الحصى بالطريقة الصحيحة دون تزاحم أو رمي أشياء كبيرة.",
                "مساعدة كبار السن وأصحاب الاحتياجات مع الالتزام بتعليمات السلامة."
            ],
            note: "لا تخاطر بسلامتك من أجل الاقتراب؛ اتبع خطط التفويج والإرشادات الرسمية دائمًا."
        },
        {
            kicker: "من أعمال يوم النحر",
            detail: "يطوف الحاج حول الكعبة سبعة أشواط طواف الإفاضة، وهو من أركان الحج، ثم يسعى بين الصفا والمروة إذا كان السعي باقيًا عليه بحسب نوع نسكه وما أدّاه سابقًا.",
            points: [
                "التأكد من معرفة نقطة بداية الطواف واتّباع اتجاه الحركة المحدد.",
                "إكمال سبعة أشواط مع تجنّب التدافع والوقوف في الممرات.",
                "استفسر من مرشدك عن ترتيب الطواف والسعي والتحلل المناسب لحالتك."
            ],
            note: "قد يختلف ترتيب بعض الأعمال باختلاف نوع النسك والقدرة والظروف؛ استفتِ مرشدًا مؤهلًا عند الحاجة."
        },
        {
            kicker: "ختام الرحلة قبل مغادرة مكة",
            detail: "يكون طواف الوداع عند إرادة مغادرة مكة بعد إتمام أعمال الحج، وهو واجب على من وجب عليه وفق الأحكام الشرعية، مع وجود أحكام خاصة لبعض الفئات، ومنها الحائض والنفساء.",
            points: [
                "التنسيق مع الحملة بشأن وقت المغادرة والنقل والأمتعة.",
                "إتمام الطواف وفق الأحكام الشرعية المتعلقة بحالة الحاج.",
                "التأكد من الأغراض الشخصية ومواعيد التجمع قبل السفر."
            ],
            note: "هذا المحتوى للتعريف العام ولا يغني عن الفتوى الشرعية أو تعليمات الجهات الرسمية للحج."
        }
    ],

    en: [
        {
            kicker: "Preparation and Beginning of Hajj",
            detail: "The pilgrim enters Ihram at the designated Miqat, makes the intention to begin Hajj, and recites the Talbiyah: 'Labbayka Allahumma labbayk, labbayka la sharika laka labbayk.' Ihram is the intention to enter the pilgrimage rites, not merely wearing Ihram clothing.",
            points: [
                "Perform Ghusl, prepare yourself, and wear appropriate Ihram clothing.",
                "Make the intention for Hajj and recite the Talbiyah while observing the restrictions of Ihram.",
                "Treat others kindly and follow the instructions of the organizing authorities."
            ],
            note: "The details of Hajj vary depending on the type of pilgrimage and the pilgrim's circumstances. Consult a reliable source or qualified religious guide."
        },
        {
            kicker: "8th of Dhul-Hijjah",
            detail: "On the Day of Tarwiyah, pilgrims travel to Mina, where they spend time praying, remembering Allah, and preparing for the standing at Arafat. They should move calmly with their group and follow official routes and instructions.",
            points: [
                "Confirm your camp location, group number, and supervisor's contact information.",
                "Perform prayers according to the Islamic rulings related to travel and Hajj.",
                "Prepare drinking water, essential personal medications, and necessary supplies."
            ],
            note: "Transportation and accommodation arrangements may vary depending on the official pilgrimage program. Follow your supervisors' instructions."
        },
        {
            kicker: "9th of Dhul-Hijjah",
            detail: "Standing at Arafat is an essential pillar of Hajj. Pilgrims spend this day making supplications, remembering Allah, seeking forgiveness, and worshipping Him. They should drink enough water, rest, and avoid excessive sun exposure.",
            points: [
                "Ensure that you are within the boundaries of Arafat during the prescribed time.",
                "Increase supplication, Talbiyah, and remembrance of Allah while allowing time for rest.",
                "Stay with your group and do not leave without coordination."
            ],
            note: "Climbing Jabal al-Rahmah is not required for a valid standing at Arafat. What matters is being within Arafat's boundaries at the prescribed time."
        },
        {
            kicker: "Night of the 10th of Dhul-Hijjah",
            detail: "After leaving Arafat, pilgrims travel to Muzdalifah, where they combine the Maghrib and Isha prayers according to Islamic rulings. They stay overnight as required by their circumstances and approved arrangements, then prepare to proceed to Mina.",
            points: [
                "Follow transportation instructions and approved departure schedules.",
                "Rest and prepare for the next day, collecting pebbles if needed according to guidance.",
                "Maintain cleanliness and keep pedestrian pathways clear."
            ],
            note: "Special rulings and concessions apply to different groups of pilgrims. Consult a qualified religious guide and official authorities."
        },
        {
            kicker: "Day of Sacrifice and Days of Tashreeq",
            detail: "On the Day of Sacrifice, pilgrims stone Jamarat al-Aqabah. During the Days of Tashreeq, they stone the Jamarat according to the prescribed order and times. This act of worship should be performed calmly without pushing or harming others.",
            points: [
                "Follow the times and routes assigned by your Hajj group and organizing authorities.",
                "Throw the pebbles correctly without crowding or throwing large objects.",
                "Assist elderly pilgrims and people with special needs while following safety instructions."
            ],
            note: "Never risk your safety to get closer. Always follow crowd-management plans and official guidance."
        },
        {
            kicker: "Rituals of the Day of Sacrifice",
            detail: "The pilgrim performs Tawaf al-Ifadah by circling the Kaaba seven times. This is an essential pillar of Hajj. The pilgrim then performs Sa'i between Safa and Marwah if it remains required, depending on the type of Hajj and previously completed rituals.",
            points: [
                "Identify the starting point of Tawaf and follow the designated direction of movement.",
                "Complete seven circuits while avoiding pushing and blocking walkways.",
                "Ask your guide about the appropriate order of Tawaf, Sa'i, and release from Ihram."
            ],
            note: "The order of certain rituals may vary depending on the type of Hajj, ability, and circumstances. Consult a qualified guide when necessary."
        },
        {
            kicker: "Final Ritual Before Leaving Makkah",
            detail: "Tawaf al-Wada is performed when preparing to leave Makkah after completing the Hajj rituals. It is obligatory for those to whom the ruling applies, with specific exemptions, including for menstruating women and women experiencing postpartum bleeding.",
            points: [
                "Coordinate departure time, transportation, and luggage arrangements with your Hajj group.",
                "Complete Tawaf according to the Islamic rulings applicable to your circumstances.",
                "Check your personal belongings and meeting times before departure."
            ],
            note: "This information is for general guidance and does not replace qualified religious advice or official Hajj instructions."
        }
    ],

    id: [
        {
            kicker: "Persiapan dan Awal Ibadah Haji",
            detail: "Jemaah haji memulai ihram dari miqat yang telah ditentukan, berniat memasuki ibadah haji, dan membaca talbiyah: 'Labbaik Allahumma labbaik, labbaika la syarika laka labbaik.' Ihram adalah niat untuk memasuki ibadah haji, bukan sekadar mengenakan pakaian ihram.",
            points: [
                "Mandi, mempersiapkan diri, dan mengenakan pakaian ihram yang sesuai.",
                "Berniat melaksanakan haji dan membaca talbiyah serta mematuhi larangan ihram.",
                "Bersikap baik kepada orang lain dan mengikuti arahan petugas penyelenggara."
            ],
            note: "Ketentuan ibadah haji dapat berbeda sesuai jenis haji dan kondisi jemaah. Pelajari dari sumber tepercaya atau tanyakan kepada pembimbing agama yang kompeten."
        },
        {
            kicker: "8 Zulhijah",
            detail: "Pada Hari Tarwiyah, jemaah haji menuju Mina untuk melaksanakan salat, berzikir, dan mempersiapkan wukuf di Arafah. Jemaah hendaknya bergerak dengan tertib bersama rombongan dan mengikuti jalur serta arahan resmi.",
            points: [
                "Pastikan lokasi tenda, nomor rombongan, dan kontak pembimbing.",
                "Laksanakan salat sesuai ketentuan syariat mengenai perjalanan dan haji.",
                "Siapkan air minum, obat pribadi yang diperlukan, dan perlengkapan penting."
            ],
            note: "Pengaturan transportasi dan akomodasi dapat berbeda sesuai program resmi penyelenggara haji. Ikuti arahan pembimbing."
        },
        {
            kicker: "9 Zulhijah",
            detail: "Wukuf di Arafah merupakan salah satu rukun utama haji. Jemaah menghabiskan hari ini dengan berdoa, berzikir, memohon ampunan, dan beribadah kepada Allah. Jemaah juga perlu cukup minum, beristirahat, dan menghindari paparan sinar matahari berlebihan.",
            points: [
                "Pastikan berada di dalam batas wilayah Arafah pada waktu wukuf yang ditentukan.",
                "Perbanyak doa, talbiyah, dan zikir sambil menyediakan waktu untuk beristirahat.",
                "Tetap bersama rombongan dan jangan meninggalkan lokasi tanpa koordinasi."
            ],
            note: "Mendaki Jabal Rahmah bukan syarat sah wukuf. Yang penting adalah berada di dalam batas wilayah Arafah pada waktunya."
        },
        {
            kicker: "Malam 10 Zulhijah",
            detail: "Setelah meninggalkan Arafah, jemaah menuju Muzdalifah dan melaksanakan salat Magrib dan Isya secara jamak sesuai ketentuan syariat. Jemaah bermalam sesuai kemampuan dan pengaturan yang berlaku, kemudian bersiap menuju Mina.",
            points: [
                "Ikuti petunjuk transportasi dan jadwal keberangkatan yang ditetapkan.",
                "Beristirahat dan bersiap untuk hari berikutnya, serta mengumpulkan kerikil jika diperlukan sesuai arahan.",
                "Jaga kebersihan dan jangan menghalangi jalur pejalan kaki."
            ],
            note: "Terdapat ketentuan dan keringanan khusus bagi kelompok jemaah tertentu. Konsultasikan dengan pembimbing agama dan pihak berwenang."
        },
        {
            kicker: "Hari Nahar dan Hari Tasyrik",
            detail: "Pada Hari Nahar, jemaah melempar Jumrah Aqabah. Selama Hari Tasyrik, jemaah melempar jumrah sesuai urutan dan waktu yang ditentukan. Ibadah ini harus dilakukan dengan tenang tanpa berdesakan atau membahayakan orang lain.",
            points: [
                "Patuhi waktu dan jalur yang ditetapkan oleh rombongan dan petugas penyelenggara.",
                "Lempar kerikil dengan benar tanpa berdesakan atau melempar benda besar.",
                "Bantu jemaah lanjut usia dan yang membutuhkan bantuan sambil mematuhi petunjuk keselamatan."
            ],
            note: "Jangan membahayakan diri demi mendekat ke lokasi pelemparan. Selalu ikuti pengaturan pergerakan jemaah dan petunjuk resmi."
        },
        {
            kicker: "Amalan pada Hari Nahar",
            detail: "Jemaah melaksanakan Tawaf Ifadah dengan mengelilingi Ka'bah sebanyak tujuh putaran. Tawaf ini merupakan salah satu rukun haji. Kemudian jemaah melaksanakan sai antara Safa dan Marwah jika masih diwajibkan sesuai jenis haji dan amalan yang telah dilakukan.",
            points: [
                "Ketahui titik awal tawaf dan ikuti arah pergerakan yang ditentukan.",
                "Selesaikan tujuh putaran tanpa berdesakan atau menghalangi jalur.",
                "Tanyakan kepada pembimbing tentang urutan tawaf, sai, dan tahalul sesuai kondisi Anda."
            ],
            note: "Urutan beberapa amalan dapat berbeda sesuai jenis haji, kemampuan, dan keadaan. Konsultasikan dengan pembimbing yang kompeten jika diperlukan."
        },
        {
            kicker: "Akhir Perjalanan Sebelum Meninggalkan Makkah",
            detail: "Tawaf Wada dilakukan ketika hendak meninggalkan Makkah setelah menyelesaikan ibadah haji. Tawaf ini wajib bagi mereka yang dikenai ketentuannya, dengan pengecualian tertentu, termasuk bagi perempuan yang sedang haid atau nifas.",
            points: [
                "Koordinasikan waktu kepulangan, transportasi, dan barang bawaan dengan rombongan.",
                "Laksanakan tawaf sesuai ketentuan syariat yang berlaku bagi kondisi Anda.",
                "Periksa barang pribadi dan jadwal berkumpul sebelum berangkat."
            ],
            note: "Informasi ini merupakan panduan umum dan tidak menggantikan fatwa dari ahli agama atau petunjuk resmi penyelenggaraan haji."
        }
    ]
};


/* ==========================================
   ترجمة عناصر التنقل
========================================== */

const manasikUI = {
    ar: {
        previous: "السابقة",
        next: "التالية",
        slide: "الشريحة",
        of: "من",
        goTo: "الانتقال إلى الشريحة",
        title: "مناسك الحج - تيسير"
    },
    en: {
        previous: "Previous",
        next: "Next",
        slide: "Slide",
        of: "of",
        goTo: "Go to slide",
        title: "Hajj Rituals - Taysir"
    },
    id: {
        previous: "Sebelumnya",
        next: "Berikutnya",
        slide: "Slide",
        of: "dari",
        goTo: "Buka slide",
        title: "Manasik Haji - Taysir"
    }
};


/* ==========================================
   تطبيق ترجمة تفاصيل المناسك
========================================== */

function applyManasikTranslations(lang) {

    if (!manasikTranslations[lang]) {
        lang = "ar";
    }

    const slides = document.querySelectorAll(".manasik-slide");
    const data = manasikTranslations[lang];
    const ui = manasikUI[lang];

    slides.forEach(function(slide, index) {

        const content = data[index];

        if (!content) return;

        const kicker = slide.querySelector(".manasik-kicker");
        const detail = slide.querySelector(".manasik-detail");
        const points = slide.querySelectorAll(".manasik-points li");
        const note = slide.querySelector(".manasik-note");

        if (kicker) {
            kicker.textContent = content.kicker;
        }

        if (detail) {
            detail.textContent = content.detail;
        }

        points.forEach(function(point, i) {
            if (content.points[i]) {
                point.textContent = content.points[i];
            }
        });

        if (note) {
            note.textContent = content.note;
        }

    });

    /* أزرار السابق والتالي */

    const prev = document.getElementById("manasikPrev");
    const next = document.getElementById("manasikNext");

    if (prev) {
        prev.textContent = lang === "ar"
            ? "→ " + ui.previous
            : "← " + ui.previous;

        prev.setAttribute("aria-label", ui.previous);
    }

    if (next) {
        next.textContent = lang === "ar"
            ? ui.next + " ←"
            : ui.next + " →";

        next.setAttribute("aria-label", ui.next);
    }

    /* تحديث رقم الشريحة */

    const progress = document.getElementById("manasikProgress");
    const activeSlide = Array.from(slides).findIndex(
        slide => slide.classList.contains("is-active")
    );

    const current = activeSlide >= 0 ? activeSlide + 1 : 1;

    const formatNumber = number =>
        lang === "ar"
            ? String(number).replace(/[0-9]/g, d => "٠١٢٣٤٥٦٧٨٩"[d])
            : String(number);

    if (progress) {
        progress.textContent =
            ui.slide + " " +
            formatNumber(current) + " " +
            ui.of + " " +
            formatNumber(slides.length);
    }

    /* تحديث أرقام الشرائح */

    slides.forEach(function(slide, index) {
        const number = slide.querySelector(".manasik-number");

        if (number) {
            number.textContent = formatNumber(index + 1);
        }
    });

    /* نقاط التنقل */

    document.querySelectorAll(".manasik-dot").forEach(
        function(dot, index) {
            dot.setAttribute(
                "aria-label",
                ui.goTo + " " + formatNumber(index + 1)
            );
        }
    );

    document.title = ui.title;
}


/* ==========================================
   معرفة اللغة الحالية
========================================== */

function getManasikLanguage() {
    return localStorage.getItem("siteLanguage") || "ar";
}


/* ==========================================
   تشغيل الترجمة عند فتح الصفحة
========================================== */

function initializeManasikTranslation() {
    applyManasikTranslations(getManasikLanguage());
}

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        initializeManasikTranslation
    );
} else {
    initializeManasikTranslation();
}


/* ==========================================
   الربط مع زر تغيير اللغة الحالي
========================================== */

if (typeof setLanguage === "function") {

    const originalSetLanguage = setLanguage;

    setLanguage = function(lang) {

        originalSetLanguage(lang);

        const activeLanguage = getManasikLanguage();

        applyManasikTranslations(activeLanguage);
    };
}


/* ==========================================
   تحديث عداد الشرائح عند التنقل
========================================== */

document.addEventListener("click", function(event) {

    const control = event.target.closest(
        "#manasikPrev, #manasikNext, .manasik-dot"
    );

    if (control) {

        requestAnimationFrame(function() {
            applyManasikTranslations(getManasikLanguage());
        });

    }
});
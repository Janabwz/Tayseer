<?php
require_once 'db.php';

$messageKey = '';
$messageType = 'error';
$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {

        $messageKey = 'registerRequired';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $messageKey = 'registerInvalidEmail';

    } elseif (strlen($password) < 8) {

        $messageKey = 'registerShortPassword';

    } else {

        $check = $conn->prepare(
            'SELECT Email FROM users WHERE Email = ? LIMIT 1'
        );

        if (!$check) {

            $messageKey = 'registerDatabaseError';

        } else {

            $check->bind_param('s', $email);
            $check->execute();

            $existing = $check->get_result();

            $emailExists = $existing && $existing->num_rows > 0;

            $check->close();

            if ($emailExists) {

                $messageKey = 'registerEmailExists';

            } else {

                $passwordHash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $insert = $conn->prepare(
                    'INSERT INTO users
                    (Name, Email, Password)
                    VALUES (?, ?, ?)'
                );

                if ($insert) {

                    $insert->bind_param(
                        'sss',
                        $name,
                        $email,
                        $passwordHash
                    );

                    if ($insert->execute()) {

                        $messageKey = 'registerSuccess';
                        $messageType = 'success';

                        $name = '';
                        $email = '';

                    } else {

                        $messageKey = 'registerFailed';

                    }

                    $insert->close();

                } else {

                    $messageKey = 'registerDatabaseError';

                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title data-i18n="registerPageTitle">
        إنشاء حساب - تيسير
    </title>

    <link rel="stylesheet" href="style.css">

    <link
        href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap"
        rel="stylesheet"
    >

    <script src="language.js" defer></script>
</head>

<body>

<div class="register-page">

    <main class="register-card">

        <a href="index.php"
           aria-label="العودة إلى الصفحة الرئيسية"
           data-i18n-aria-label="registerBackHome">

            <img
                src="images/logo.png"
                alt="شعار تيسير"
                class="register-logo"
            >

        </a>

        <h1 data-i18n="register">
            إنشاء حساب
        </h1>

        <p class="register-subtitle"
           data-i18n="registerSubtitle">

            أنشئي حسابك وابدئي رحلتك مع تيسير

        </p>

        <?php if ($messageKey !== ''): ?>

            <p
                class="auth-message <?php echo $messageType === 'success' ? 'success' : ''; ?>"
                data-i18n="<?php echo htmlspecialchars($messageKey, ENT_QUOTES, 'UTF-8'); ?>"
                role="status"
            >
                <?php
                $arabicMessages = [
                    'registerRequired' => 'فضلاً املئي جميع الحقول.',
                    'registerInvalidEmail' => 'صيغة البريد الإلكتروني غير صحيحة.',
                    'registerShortPassword' => 'اجعلي كلمة المرور 8 أحرف على الأقل.',
                    'registerDatabaseError' => 'تعذر تنفيذ التسجيل. تأكدي من إعداد قاعدة البيانات.',
                    'registerEmailExists' => 'هذا البريد الإلكتروني مسجل من قبل. جرّبي تسجيل الدخول.',
                    'registerSuccess' => 'تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول.',
                    'registerFailed' => 'لم نتمكن من إنشاء الحساب. تحققي من البيانات وحاولي مرة أخرى.'
                ];

                echo htmlspecialchars(
                    $arabicMessages[$messageKey] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>
            </p>

        <?php endif; ?>

        <form
            method="POST"
            action="register.php"
            autocomplete="on"
        >

            <label
                for="name"
                data-i18n="nameLabel"
            >
                الاسم
            </label>

            <input
                id="name"
                type="text"
                name="name"
                placeholder="أدخلي اسمك"
                data-i18n-placeholder="namePlaceholder"
                value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>"
                autocomplete="name"
                required
            >

            <label
                for="email"
                data-i18n="emailLabel"
            >
                البريد الإلكتروني
            </label>

            <input
                id="email"
                type="email"
                name="email"
                placeholder="أدخلي بريدك الإلكتروني"
                data-i18n-placeholder="emailPlaceholder"
                value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                autocomplete="email"
                required
            >

            <label
                for="password"
                data-i18n="passwordLabel"
            >
                كلمة المرور
            </label>

            <input
                id="password"
                type="password"
                name="password"
                placeholder="8 أحرف على الأقل"
                data-i18n-placeholder="passwordPlaceholder"
                minlength="8"
                autocomplete="new-password"
                required
            >

            <button
                type="submit"
                data-i18n="registerButton"
            >
                إنشاء حساب
            </button>

        </form>

        <p class="login-link">

            <span data-i18n="alreadyHaveAccount">
                لديك حساب بالفعل؟
            </span>

            <a
                href="login.php"
                data-i18n="login"
            >
                تسجيل الدخول
            </a>

        </p>

        <p class="login-link">

            <a
                href="index.php"
                data-i18n="registerBackHome"
            >
                العودة إلى الصفحة الرئيسية
            </a>

        </p>

    </main>

</div>

</body>
</html>

const CACHE_NAME = "taysir-v8";

const APP_FILES = [
  "./index.php",
  "./mansik.html",
  "./map.html",
  "./quiz.html",
  "./style.css",
  "./language.js",
  "./mansik-translations.js",
  "./hajj-types-translations.js",
  "./congratulations.html",
  "./manifest.json",
  "./images/icon-192.png",
  "./images/icon-512.png",
  "./images/icon-maskable-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      await Promise.allSettled(
        APP_FILES.map((file) => cache.add(file))
      );
    })
  );

  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();

      await Promise.all(
        keys
          .filter((key) => key.startsWith("taysir-") && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      );

      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;

  if (request.method !== "GET") return;

  const url = new URL(request.url);

  if (url.origin !== self.location.origin) return;

  // لا نخزن صفحات الحسابات أو بيانات المستخدمين
  if (
    url.pathname.endsWith("/login.php") ||
    url.pathname.endsWith("/register.php") ||
    url.pathname.endsWith("/db.php")
  ) {
    return;
  }

  // الصفحة الرئيسية
  if (
    request.mode === "navigate" &&
    (url.pathname === "/" || url.pathname.endsWith("/index.php"))
  ) {
    event.respondWith(
      fetch(request).catch(async () => {
        return (
          (await caches.match("./index.php")) ||
          Response.error()
        );
      })
    );
    return;
  }

  // صفحات المناسك والكويز والملفات الثابتة
  event.respondWith(
    caches.match(request, { ignoreSearch: true }).then((cached) => {
      return cached || fetch(request);
    })
  );
});
<?php
session_start();
require_once 'db.php';

$messageKey = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {

        $messageKey = 'loginRequired';

    } else {

        $stmt = $conn->prepare(
            'SELECT Name, Email, Password
             FROM users
             WHERE Email = ?
             LIMIT 1'
        );

        if ($stmt) {

            $stmt->bind_param('s', $email);
            $stmt->execute();

            $result = $stmt->get_result();
            $user = $result ? $result->fetch_assoc() : null;

            $stmt->close();

            $validPassword = false;

            if ($user) {

                $storedPassword = (string)$user['Password'];

                // دعم كلمات المرور المشفرة والقديمة
                $passwordInfo = password_get_info($storedPassword);

                if ($passwordInfo['algo'] !== null &&
                    $passwordInfo['algo'] !== 0) {

                    $validPassword = password_verify(
                        $password,
                        $storedPassword
                    );

                } else {

                    $validPassword = hash_equals(
                        $storedPassword,
                        $password
                    );

                    if ($validPassword) {

                        $newHash = password_hash(
                            $password,
                            PASSWORD_DEFAULT
                        );

                        $update = $conn->prepare(
                            'UPDATE users
                             SET Password = ?
                             WHERE Email = ?'
                        );

                        if ($update) {

                            $update->bind_param(
                                'ss',
                                $newHash,
                                $email
                            );

                            $update->execute();
                            $update->close();
                        }
                    }
                }
            }

            if ($user && $validPassword) {

                session_regenerate_id(true);

                $_SESSION['user_name'] = $user['Name'];
                $_SESSION['user_email'] = $user['Email'];

                header('Location: index.php');
                exit;
            }

            $messageKey = 'loginInvalid';

        } else {

            $messageKey = 'loginDatabaseError';

        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title data-i18n="loginPageTitle">
        تسجيل الدخول - تيسير
    </title>

    <link rel="stylesheet" href="style.css">

    <link
        href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap"
        rel="stylesheet"
    >

    <script src="language.js" defer></script>
</head>

<body>

<div class="register-page">

    <main class="register-card">

        <a
            href="index.php"
            aria-label="العودة إلى الصفحة الرئيسية"
            data-i18n-aria-label="registerBackHome"
        >

            <img
                src="images/logo.png"
                alt="شعار تيسير"
                class="register-logo"
            >

        </a>

        <h1 data-i18n="login">
            تسجيل الدخول
        </h1>

        <p
            class="register-subtitle"
            data-i18n="loginSubtitle"
        >
            أهلاً بك مرة أخرى في تيسير
        </p>

        <?php if ($messageKey !== ''): ?>

            <p
                class="auth-message"
                role="alert"
                data-i18n="<?php echo htmlspecialchars($messageKey, ENT_QUOTES, 'UTF-8'); ?>"
            >
                <?php
                $arabicMessages = [
                    'loginRequired' =>
                        'فضلاً أدخل البريد الإلكتروني وكلمة المرور.',

                    'loginInvalid' =>
                        'البريد الإلكتروني أو كلمة المرور غير صحيحة.',

                    'loginDatabaseError' =>
                        'تعذر تنفيذ تسجيل الدخول. تأكدي من إعداد قاعدة البيانات.'
                ];

                echo htmlspecialchars(
                    $arabicMessages[$messageKey] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>
            </p>

        <?php endif; ?>

        <form
            method="POST"
            action="login.php"
            autocomplete="on"
        >

            <label
                for="email"
                data-i18n="emailLabel"
            >
                البريد الإلكتروني
            </label>

            <input
                id="email"
                type="email"
                name="email"
                placeholder="أدخل بريدك الإلكتروني"
                data-i18n-placeholder="loginEmailPlaceholder"
                value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                autocomplete="email"
                required
            >

            <label
                for="password"
                data-i18n="passwordLabel"
            >
                كلمة المرور
            </label>

            <input
                id="password"
                type="password"
                name="password"
                placeholder="أدخل كلمة المرور"
                data-i18n-placeholder="loginPasswordPlaceholder"
                autocomplete="current-password"
                required
            >

            <button
                type="submit"
                data-i18n="loginButton"
            >
                دخول
            </button>

        </form>

        <p class="login-link">

            <span data-i18n="noAccount">
                ليس لديك حساب؟
            </span>

            <a
                href="register.php"
                data-i18n="createNewAccount"
            >
                إنشاء حساب جديد
            </a>

        </p>

        <p class="login-link">

            <a
                href="index.php"
                data-i18n="registerBackHome"
            >
                العودة إلى الصفحة الرئيسية
            </a>

        </p>

    </main>

</div>

</body>
</html>
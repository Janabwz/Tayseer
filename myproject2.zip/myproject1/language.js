const translations = {

    // =========================
    // العربية
    // =========================
    ar: {
        language: "اللغة",
        home: "الصفحة الرئيسية",
        contact: "التواصل",
        contents: "المحتويات",

        register: "إنشاء حساب",
        login: "تسجيل الدخول",

        heroTitle: "حجك يبدأ بالمعرفة",
        heroText: "دليلك التفاعلي الشامل لأداء مناسك الحج بكل سهولة مع أدوات تفاعلية لضمان فهمك.",

        aboutTitle: "من نحن",
        aboutDescription: "تيسير منصة تعليمية تفاعلية تُعرّف الحاج بمناسك الحج وخطواتها بأسلوب واضح ومبسّط، مع خرائط واختبارات تعزّز الفهم.",

        contentsTitle: "المحتويات",
        mapTitle: "خريطة المشاعر المقدسة",
        view: "استعراض",
        mapDescription: "استكشف خريطة المشاعر المقدسة وتعرّف على مواقع منى وعرفات ومزدلفة، من خلال عرض يساعدك على معرفة أماكن المناسك والتنقّل بينها بسهولة ووضوح، لتكون رحلتك في أداء مناسك الحج أكثر يسرًا وطمأنينة.",

        manasikTitle: "مناسك الحج",
        manasikText: "دليل تفصيلي يرافقك خطوة بخطوة لمناسك الحج بدءًا من الإحرام وحتى طواف الوداع مع توضيح بالصور لضمان أداء المناسك بكل سهولة ويسر.",

        startJourney: "ابدأ رحلتك الآن",
        contactTitle: "التواصل",

        languageArabic: "العربية",
        languageEnglish: "الإنجليزية",
        languageIndonesian: "الإندونيسية",

        // صفحة مناسك الحج
        simulator: "محاكي الحج",
        manasikNav: "المناسك",
        manasikPageTitle: "مناسك الحج",
        manasikIntro: "دليلك التفاعلي للتعرف على خطوات الحج بطريقة مبسطة ومنظمة.",

        ihram: "الإحرام",
        mina: "منى",
        arafat: "عرفات",
        muzdalifah: "مزدلفة",
        jamarat: "رمي الجمرات",
        tawafIfadah: "طواف الإفاضة",
        tawafWadaa: "طواف الوداع",

        ihramText: "الاستعداد للحج والدخول في النسك مع عقد النية والتلبية.",
        minaText: "التوجه إلى منى والمبيت فيها وأداء الأعمال المتعلقة بيوم التروية.",
        arafatText: "الوقوف بعرفة في اليوم التاسع من ذي الحجة والإكثار من الدعاء والذكر.",
        muzdalifahText: "الإفاضة من عرفات إلى مزدلفة والمبيت فيها وفق أحكام الحج.",
        jamaratText: "التوجه إلى الجمرات في منى ورمي الجمرات في الأيام المحددة.",
        tawafIfadahText: "الطواف حول الكعبة سبعة أشواط وفق أحكام الحج.",
        tawafWadaaText: "ختام رحلة الحج بطواف الوداع عند مغادرة مكة وفق الأحكام المتعلقة به.",

        backHome: "العودة للرئيسية",
        footerTitle: "تيسير - محاكي الحج",

        // إنشاء حساب
        registerPageTitle: "إنشاء حساب - تيسير",
        registerSubtitle: "أنشئي حسابك وابدئي رحلتك مع تيسير",
        nameLabel: "الاسم",
        namePlaceholder: "أدخلي اسمك",
        emailLabel: "البريد الإلكتروني",
        emailPlaceholder: "أدخلي بريدك الإلكتروني",
        passwordLabel: "كلمة المرور",
        passwordPlaceholder: "8 أحرف على الأقل",
        alreadyHaveAccount: "لديك حساب بالفعل؟",
        registerButton: "إنشاء حساب",
        registerBackHome: "العودة إلى الصفحة الرئيسية",

        registerRequired: "فضلاً املئي جميع الحقول.",
        registerInvalidEmail: "صيغة البريد الإلكتروني غير صحيحة.",
        registerShortPassword: "اجعلي كلمة المرور 8 أحرف على الأقل.",
        registerDatabaseError: "تعذر تنفيذ التسجيل. تأكدي من إعداد قاعدة البيانات.",
        registerEmailExists: "هذا البريد الإلكتروني مسجل من قبل. جرّبي تسجيل الدخول.",
        registerSuccess: "تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول.",
        registerFailed: "لم نتمكن من إنشاء الحساب. تحققي من البيانات وحاولي مرة أخرى.",

        // تسجيل الدخول
        loginPageTitle: "تسجيل الدخول - تيسير",
        loginSubtitle: "أهلاً بك مرة أخرى في تيسير",
        loginEmailPlaceholder: "أدخل بريدك الإلكتروني",
        loginPasswordPlaceholder: "أدخل كلمة المرور",
        loginButton: "دخول",
        noAccount: "ليس لديك حساب؟",
        createNewAccount: "إنشاء حساب جديد",
        loginRequired: "فضلاً أدخل البريد الإلكتروني وكلمة المرور.",
        loginInvalid: "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
        loginDatabaseError: "تعذر تنفيذ تسجيل الدخول. تأكدي من إعداد قاعدة البيانات.",

        // Footer بدون روابط التواصل
        footerDescription: "تيسير، رفيقك للتعرّف على مناسك الحج بخطوات واضحة.",
        phoneLabel: "الهاتف"
    },

    // =========================
    // English
    // =========================
    en: {
        language: "Language",
        home: "Home",
        contact: "Contact",
        contents: "Contents",

        register: "Create Account",
        login: "Login",

        heroTitle: "Your Hajj Begins with Knowledge",
        heroText: "Your comprehensive interactive guide to performing Hajj rituals with ease, supported by interactive tools to help you understand.",

        aboutTitle: "About Us",
        aboutDescription: "Taysir is an interactive learning platform that explains Hajj rites in a clear, simple way, using maps and quizzes to support understanding.",

        contentsTitle: "Contents",
        mapTitle: "Holy Sites Map",
        view: "View",
        mapDescription: "Explore the map of the holy sites and discover the locations of Mina, Arafat, and Muzdalifah. This interactive guide helps you understand the locations of Hajj rituals and navigate between them easily and clearly, making your pilgrimage journey smoother and more peaceful.",

        manasikTitle: "Hajj Rituals",
        manasikText: "A detailed guide that accompanies you step by step through the Hajj rituals, from Ihram to the Farewell Tawaf, with illustrations to make performing the rituals easy.",

        startJourney: "Start Your Journey",
        contactTitle: "Contact",

        languageArabic: "Arabic",
        languageEnglish: "English",
        languageIndonesian: "Indonesian",

        // Hajj Rituals
        simulator: "Hajj Simulator",
        manasikNav: "Rituals",
        manasikPageTitle: "Hajj Rituals",
        manasikIntro: "Your interactive guide to learning the steps of Hajj in a simple and organized way.",

        ihram: "Ihram",
        mina: "Mina",
        arafat: "Arafat",
        muzdalifah: "Muzdalifah",
        jamarat: "Stoning the Jamarat",
        tawafIfadah: "Tawaf al-Ifadah",
        tawafWadaa: "Farewell Tawaf",

        ihramText: "Preparing for Hajj and entering the ritual by making the intention and reciting the Talbiyah.",
        minaText: "Going to Mina, staying there overnight, and performing the rituals related to the Day of Tarwiyah.",
        arafatText: "Standing at Arafat on the ninth day of Dhul-Hijjah while increasing supplication and remembrance of Allah.",
        muzdalifahText: "Traveling from Arafat to Muzdalifah and staying there overnight according to the Hajj rulings.",
        jamaratText: "Going to the Jamarat in Mina and performing the stoning ritual on the designated days.",
        tawafIfadahText: "Circling the Kaaba seven times according to the Hajj rulings.",
        tawafWadaaText: "Concluding the Hajj journey with the Farewell Tawaf when leaving Makkah according to its rulings.",

        backHome: "Back to Home",
        footerTitle: "Taysir - Hajj Simulator",

        // Create Account
        registerPageTitle: "Create Account - Taysir",
        registerSubtitle: "Create your account and start your journey with Taysir",
        nameLabel: "Name",
        namePlaceholder: "Enter your name",
        emailLabel: "Email Address",
        emailPlaceholder: "Enter your email address",
        passwordLabel: "Password",
        passwordPlaceholder: "At least 8 characters",
        alreadyHaveAccount: "Already have an account?",
        registerButton: "Create Account",
        registerBackHome: "Back to Home",

        registerRequired: "Please fill in all fields.",
        registerInvalidEmail: "Please enter a valid email address.",
        registerShortPassword: "Password must contain at least 8 characters.",
        registerDatabaseError: "Registration could not be completed. Please check the database configuration.",
        registerEmailExists: "This email is already registered. Please log in.",
        registerSuccess: "Account created successfully! You can now log in.",
        registerFailed: "We could not create your account. Please check your details and try again.",

        // Login
        loginPageTitle: "Login - Taysir",
        loginSubtitle: "Welcome back to Taysir",
        loginEmailPlaceholder: "Enter your email address",
        loginPasswordPlaceholder: "Enter your password",
        loginButton: "Login",
        noAccount: "Don't have an account?",
        createNewAccount: "Create a New Account",
        loginRequired: "Please enter your email address and password.",
        loginInvalid: "Incorrect email address or password.",
        loginDatabaseError: "Unable to log in. Please check the database configuration.",

        // Footer without social links
        footerDescription: "Taysir, your companion for learning Hajj rituals through clear and simple steps.",
        phoneLabel: "Phone"
    },

    // =========================
    // Bahasa Indonesia
    // =========================
    id: {
        language: "Bahasa",
        home: "Beranda",
        contact: "Kontak",
        contents: "Konten",

        register: "Buat Akun",
        login: "Masuk",

        heroTitle: "Haji Anda Dimulai dengan Pengetahuan",
        heroText: "Panduan interaktif lengkap untuk melaksanakan ibadah haji dengan mudah, dilengkapi berbagai alat interaktif untuk membantu Anda memahami setiap langkah.",

        aboutTitle: "Tentang Kami",
        aboutDescription: "Taysir adalah platform pembelajaran interaktif yang menjelaskan rangkaian ibadah haji dengan jelas dan sederhana melalui peta serta kuis.",

        contentsTitle: "Konten",
        mapTitle: "Peta Tempat Suci",
        view: "Lihat",
        mapDescription: "Jelajahi peta tempat-tempat suci dan kenali lokasi Mina, Arafah, dan Muzdalifah. Panduan interaktif ini membantu Anda memahami lokasi pelaksanaan ibadah haji dan berpindah di antara tempat-tempat tersebut dengan mudah dan jelas, sehingga perjalanan haji Anda menjadi lebih lancar dan tenang.",

        manasikTitle: "Manasik Haji",
        manasikText: "Panduan lengkap yang menemani Anda langkah demi langkah dalam melaksanakan ibadah haji, mulai dari ihram hingga tawaf wada, dilengkapi gambar untuk memudahkan pelaksanaan ibadah.",

        startJourney: "Mulai Perjalanan Anda",
        contactTitle: "Kontak",

        languageArabic: "Arab",
        languageEnglish: "Inggris",
        languageIndonesian: "Bahasa Indonesia",

        // Manasik Haji
        simulator: "Simulasi Haji",
        manasikNav: "Manasik",
        manasikPageTitle: "Manasik Haji",
        manasikIntro: "Panduan interaktif untuk mempelajari langkah-langkah haji dengan cara yang sederhana dan terorganisir.",

        ihram: "Ihram",
        mina: "Mina",
        arafat: "Arafah",
        muzdalifah: "Muzdalifah",
        jamarat: "Melempar Jumrah",
        tawafIfadah: "Tawaf Ifadah",
        tawafWadaa: "Tawaf Wada",

        ihramText: "Mempersiapkan diri untuk haji dan memasuki ihram dengan niat serta membaca talbiyah.",
        minaText: "Menuju Mina, bermalam di sana, dan melaksanakan amalan yang berkaitan dengan Hari Tarwiyah.",
        arafatText: "Wukuf di Arafah pada tanggal 9 Dzulhijjah sambil memperbanyak doa dan zikir.",
        muzdalifahText: "Berangkat dari Arafah menuju Muzdalifah dan bermalam di sana sesuai dengan ketentuan haji.",
        jamaratText: "Menuju Jamarat di Mina dan melaksanakan lempar jumrah pada hari-hari yang telah ditentukan.",
        tawafIfadahText: "Melaksanakan tawaf mengelilingi Ka'bah sebanyak tujuh putaran sesuai dengan ketentuan haji.",
        tawafWadaaText: "Mengakhiri perjalanan haji dengan Tawaf Wada saat meninggalkan Makkah sesuai dengan ketentuannya.",

        backHome: "Kembali ke Beranda",
        footerTitle: "Taysir - Simulasi Haji",

        // Buat Akun
        registerPageTitle: "Buat Akun - Taysir",
        registerSubtitle: "Buat akun Anda dan mulai perjalanan bersama Taysir",
        nameLabel: "Nama",
        namePlaceholder: "Masukkan nama Anda",
        emailLabel: "Alamat Email",
        emailPlaceholder: "Masukkan alamat email Anda",
        passwordLabel: "Kata Sandi",
        passwordPlaceholder: "Minimal 8 karakter",
        alreadyHaveAccount: "Sudah punya akun?",
        registerButton: "Buat Akun",
        registerBackHome: "Kembali ke Beranda",

        registerRequired: "Silakan isi semua kolom.",
        registerInvalidEmail: "Format alamat email tidak valid.",
        registerShortPassword: "Kata sandi harus memiliki minimal 8 karakter.",
        registerDatabaseError: "Pendaftaran gagal diproses. Periksa konfigurasi basis data.",
        registerEmailExists: "Email ini sudah terdaftar. Silakan masuk.",
        registerSuccess: "Akun berhasil dibuat! Sekarang Anda dapat masuk.",
        registerFailed: "Akun tidak dapat dibuat. Periksa data Anda dan coba lagi.",

        // Masuk
        loginPageTitle: "Masuk - Taysir",
        loginSubtitle: "Selamat datang kembali di Taysir",
        loginEmailPlaceholder: "Masukkan alamat email Anda",
        loginPasswordPlaceholder: "Masukkan kata sandi Anda",
        loginButton: "Masuk",
        noAccount: "Belum punya akun?",
        createNewAccount: "Buat Akun Baru",
        loginRequired: "Silakan masukkan alamat email dan kata sandi.",
        loginInvalid: "Alamat email atau kata sandi salah.",
        loginDatabaseError: "Tidak dapat masuk. Silakan periksa konfigurasi basis data.",

        // Footer tanpa tautan media sosial
        footerDescription: "Taysir, pendamping Anda untuk mempelajari manasik haji melalui langkah-langkah yang jelas dan mudah.",
        phoneLabel: "Telepon"
    }
};


// ==========================================
// تغيير اللغة
// ==========================================

function setLanguage(lang) {

    if (!translations[lang]) {
        lang = "ar";
    }

    // حفظ اللغة
    localStorage.setItem("siteLanguage", lang);

    // تغيير اتجاه الصفحة
    const html = document.documentElement;

    html.lang = lang;
    html.dir = lang === "ar" ? "rtl" : "ltr";

    if (document.body) {
        document.body.style.direction = html.dir;
    }

    // ترجمة النصوص
    document.querySelectorAll("[data-i18n]").forEach(element => {

        const key = element.getAttribute("data-i18n");

        if (translations[lang][key] !== undefined) {
            element.textContent = translations[lang][key];
        }

    });

    // ترجمة العبارات داخل حقول الإدخال
    document.querySelectorAll("[data-i18n-placeholder]").forEach(element => {

        const key = element.getAttribute("data-i18n-placeholder");

        if (translations[lang][key] !== undefined) {
            element.placeholder = translations[lang][key];
        }

    });

    // ترجمة وصف العناصر
    document.querySelectorAll("[data-i18n-aria-label]").forEach(element => {

        const key = element.getAttribute("data-i18n-aria-label");

        if (translations[lang][key] !== undefined) {
            element.setAttribute("aria-label", translations[lang][key]);
        }

    });

    // ترجمة عنوان الصفحة عند وجود مفتاح
    const pageTitle = document.querySelector("[data-i18n-title]");

    if (pageTitle) {
        const key = pageTitle.getAttribute("data-i18n-title");

        if (translations[lang][key] !== undefined) {
            document.title = translations[lang][key];
        }
    }

    // إغلاق قائمة اللغة
    const menu = document.getElementById("languageMenu");

    if (menu) {
        menu.classList.remove("show");
    }
}


// ==========================================
// فتح وإغلاق قائمة اللغة
// ==========================================

function toggleLanguageMenu() {

    const menu = document.getElementById("languageMenu");

    if (menu) {
        menu.classList.toggle("show");
    }
}


// ==========================================
// تطبيق اللغة المحفوظة
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

    const savedLanguage =
        localStorage.getItem("siteLanguage") || "ar";

    setLanguage(savedLanguage);

});


// ==========================================
// إغلاق القائمة عند الضغط خارجها
// ==========================================

document.addEventListener("click", function (event) {

    const dropdown = document.querySelector(".language-dropdown");
    const menu = document.getElementById("languageMenu");

    if (dropdown && menu && !dropdown.contains(event.target)) {
        menu.classList.remove("show");
    }

});